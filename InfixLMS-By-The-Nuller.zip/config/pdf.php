<?php

return [
    'format'           => 'A4',
    'author'           => 'Infix LMS',
    'subject'          => '',
    'keywords'         => '', // Separate values with comma
    'creator'          => 'Infix LMS',
    'display_mode'     => 'fullpage'
];
