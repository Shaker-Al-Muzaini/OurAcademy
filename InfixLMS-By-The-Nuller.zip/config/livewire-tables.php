<?php

return [
    'theme' => 'bootstrap-4',
];
